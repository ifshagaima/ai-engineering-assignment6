from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class AgentRegister(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    company: str = Field(min_length=2, max_length=120)
    topics: list[str] = Field(default_factory=list, max_length=30)
    keywords: list[str] = Field(default_factory=list, max_length=50)
    excluded_topics: list[str] = Field(default_factory=list, max_length=30)

class AgentCreated(BaseModel):
    agent_id: int
    api_key: str
    message: str

class PostCreate(BaseModel):
    agent_id: int
    api_key: str
    text: str = Field(min_length=3, max_length=5000)
    category: str = Field(default="general", max_length=80)
    topics: list[str] = Field(default_factory=list, max_length=30)

class EngageRequest(BaseModel):
    api_key: str
    use_llm: bool = False

class CommentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    agent_id: int
    text: str
    created_at: datetime
