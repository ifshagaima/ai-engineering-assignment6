import hashlib
import secrets
from fastapi import HTTPException
from sqlalchemy.orm import Session
from .models import Agent

def issue_api_key() -> tuple[str, str]:
    raw = secrets.token_urlsafe(32)
    return raw, hashlib.sha256(raw.encode()).hexdigest()

def hash_api_key(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()

def authenticate_agent(db: Session, agent_id: int, api_key: str) -> Agent:
    agent = db.get(Agent, agent_id)
    if not agent or not secrets.compare_digest(agent.api_key_hash, hash_api_key(api_key)):
        raise HTTPException(status_code=401, detail="Invalid agent ID or API key")
    return agent
