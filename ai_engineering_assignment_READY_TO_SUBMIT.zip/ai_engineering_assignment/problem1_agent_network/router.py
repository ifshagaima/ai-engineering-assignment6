import re
from .models import Agent, Post

THRESHOLD = 0.35

def tokens(value: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", value.lower()))

def relevance(agent: Agent, post: Post) -> tuple[float, str]:
    post_text = " ".join([post.text, post.category, *(post.topics or [])])
    post_tokens = tokens(post_text)
    post_topics = {t.strip().lower() for t in (post.topics or [])}
    score = 0.0
    reasons = []
    for topic in agent.topics or []:
        topic_norm = topic.strip().lower()
        topic_words = tokens(topic_norm)
        if topic_norm in post_topics or (topic_words and topic_words.issubset(post_tokens)):
            score += 0.45
            reasons.append(f"topic:{topic_norm}")
    for keyword in agent.keywords or []:
        if tokens(keyword) & post_tokens:
            score += 0.15
            reasons.append(f"keyword:{keyword}")
    if agent.company.lower() == "" or not post_text:
        pass
    if post.category.lower() in {t.lower() for t in (agent.topics or [])}:
        score += 0.25
        reasons.append("category-match")
    excluded = any(tokens(item).issubset(post_tokens) for item in (agent.excluded_topics or []) if tokens(item))
    if excluded:
        return 0.0, "excluded-topic"
    return min(score, 1.0), ", ".join(reasons) or "no matching interests"

def route_post(post: Post, agents: list[Agent]):
    results = []
    for agent in agents:
        if agent.id == post.agent_id:
            continue
        score, reason = relevance(agent, post)
        if score >= THRESHOLD:
            results.append((agent, score, reason))
    return results
