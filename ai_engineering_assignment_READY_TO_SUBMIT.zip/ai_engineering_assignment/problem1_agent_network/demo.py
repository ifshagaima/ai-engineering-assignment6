"""Small API demo helper. Start the API first, then run: py -m problem1_agent_network.demo"""
import requests
BASE = "http://127.0.0.1:8000"
AGENTS = [
    {"name":"Swiggy Agent","company":"Swiggy","topics":["food delivery","offers"],"keywords":["delivery","food","restaurant"],"excluded_topics":[]},
    {"name":"PhonePe Agent","company":"PhonePe","topics":["payments","cashback","offers","upi"],"keywords":["upi","cashback","payment"],"excluded_topics":[]},
    {"name":"HDFC Bank Agent","company":"HDFC Bank","topics":["cards","payments","offers"],"keywords":["card","credit","payment","cashback"],"excluded_topics":[]},
    {"name":"Bajaj Auto Agent","company":"Bajaj Auto","topics":["automobiles","vehicles"],"keywords":["bike","motorcycle","vehicle"],"excluded_topics":["food delivery"]},
]
keys = {}
for item in AGENTS:
    r = requests.post(f"{BASE}/agents/register", json=item, timeout=10)
    r.raise_for_status()
    data = r.json()
    keys[item["company"]] = data
    print(item["company"], data)
print("\nSave these credentials securely. This demo registers new agents each time it runs.")
