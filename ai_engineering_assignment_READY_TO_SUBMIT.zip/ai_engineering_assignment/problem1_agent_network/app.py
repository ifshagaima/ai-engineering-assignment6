from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import select
from .database import Base, engine, get_db
from .models import Agent, Post, Notification, Comment
from .schemas import AgentRegister, AgentCreated, PostCreate, EngageRequest
from .security import issue_api_key, authenticate_agent
from .router import route_post
from .llm import draft_comment

Base.metadata.create_all(bind=engine)
app = FastAPI(title="AI Agent Social Network", version="1.0.0", description="Interest-based social network for autonomous agents")

@app.get("/")
def root():
    return {"message": "AI Agent Social Network API", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/agents/register", response_model=AgentCreated, status_code=200)
def register_agent(payload: AgentRegister, db: Session = Depends(get_db)):
    raw_key, key_hash = issue_api_key()
    agent = Agent(name=payload.name, company=payload.company, topics=payload.topics,
                  keywords=payload.keywords, excluded_topics=payload.excluded_topics,
                  api_key_hash=key_hash)
    db.add(agent)
    db.commit()
    db.refresh(agent)
    return {"agent_id": agent.id, "api_key": raw_key, "message": "Save this key; it is shown only once."}

@app.post("/posts", status_code=201)
def create_post(payload: PostCreate, db: Session = Depends(get_db)):
    author = authenticate_agent(db, payload.agent_id, payload.api_key)
    post = Post(agent_id=author.id, text=payload.text, category=payload.category, topics=payload.topics)
    db.add(post)
    db.flush()
    agents = list(db.scalars(select(Agent).where(Agent.id != author.id)).all())
    routed = route_post(post, agents)
    for agent, score, reason in routed:
        db.add(Notification(post_id=post.id, agent_id=agent.id, score=score, reason=reason))
    db.commit()
    db.refresh(post)
    return {"post_id": post.id, "author": author.company, "notifications_created": len(routed),
            "recipients": [{"agent_id": a.id, "company": a.company, "score": round(s, 3), "reason": r} for a, s, r in routed]}

@app.get("/agents/{agent_id}/notifications")
def get_notifications(agent_id: int, api_key: str = Query(...), db: Session = Depends(get_db)):
    authenticate_agent(db, agent_id, api_key)
    items = db.scalars(select(Notification).options(joinedload(Notification.post)).where(
        Notification.agent_id == agent_id).order_by(Notification.created_at.desc())).all()
    return [{"notification_id": n.id, "post_id": n.post_id, "post_text": n.post.text,
             "score": n.score, "reason": n.reason, "read": n.read} for n in items]

@app.post("/notifications/{notification_id}/engage")
def engage_notification(notification_id: int, payload: EngageRequest, db: Session = Depends(get_db)):
    notification = db.get(Notification, notification_id)
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    agent = authenticate_agent(db, notification.agent_id, payload.api_key)
    post = db.get(Post, notification.post_id)
    text = draft_comment(post.text, agent.company, payload.use_llm)
    comment = Comment(post_id=post.id, agent_id=agent.id, text=text)
    notification.read = True
    db.add(comment)
    db.commit()
    db.refresh(comment)
    return {"comment_id": comment.id, "post_id": post.id, "agent": agent.company, "text": comment.text}

@app.get("/posts/{post_id}")
def get_post(post_id: int, db: Session = Depends(get_db)):
    post = db.scalar(select(Post).options(joinedload(Post.comments)).where(Post.id == post_id))
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"post_id": post.id, "agent_id": post.agent_id, "text": post.text,
            "category": post.category, "topics": post.topics,
            "comments": [{"id": c.id, "agent_id": c.agent_id, "text": c.text} for c in post.comments]}

@app.delete("/posts/{post_id}")
def delete_post(post_id: int, agent_id: int, api_key: str, db: Session = Depends(get_db)):
    authenticate_agent(db, agent_id, api_key)
    post = db.get(Post, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.agent_id != agent_id:
        raise HTTPException(status_code=403, detail="Only the author can delete this post")
    db.delete(post)
    db.commit()
    return {"message": "Post deleted"}
