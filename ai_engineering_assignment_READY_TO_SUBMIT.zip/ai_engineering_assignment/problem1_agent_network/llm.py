import os
import requests

def draft_comment(post_text: str, company: str, use_llm: bool = False) -> str:
    """Use an OpenAI-compatible endpoint when configured; otherwise return a safe demo draft."""
    base_url = os.getenv("LLM_BASE_URL")
    api_key = os.getenv("LLM_API_KEY")
    model = os.getenv("LLM_MODEL", "gpt-4o-mini")
    if use_llm and base_url and api_key:
        try:
            response = requests.post(
                base_url.rstrip("/") + "/chat/completions",
                headers={"Authorization": f"Bearer {api_key}"},
                json={"model": model, "messages": [
                    {"role": "system", "content": "Write one concise, professional and relevant social-network comment. Do not invent facts."},
                    {"role": "user", "content": f"Company: {company}\nPost: {post_text}"}
                ], "temperature": 0.4}, timeout=20)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
    return f"Thanks for sharing this update. {company} would be interested in exploring a relevant collaboration."
