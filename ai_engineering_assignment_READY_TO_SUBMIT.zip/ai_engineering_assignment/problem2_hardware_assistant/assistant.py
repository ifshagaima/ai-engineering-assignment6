from .hardware import run_readonly_tool

INTENTS = {
    "cpu": ("cpu", ("cpu", "processor", "core", "architecture")),
    "memory": ("memory", ("ram", "memory")),
    "disks": ("disks", ("disk", "drive", "ssd", "hdd", "storage", "nvme")),
    "pci": ("pci", ("gpu", "graphics", "display", "pci", "device")),
}

class HardwareAssistant:
    def __init__(self):
        self.last_tool = None
        self.last_output = None

    def answer(self, question: str) -> str:
        q = question.lower().strip()
        if q in {"and what about it?", "tell me more", "more details", "what about that?"} and self.last_tool:
            tool = self.last_tool
        else:
            matches = [key for key, (_, terms) in INTENTS.items() if any(term in q for term in terms)]
            if not matches:
                return "I can help with CPU, RAM, disks/storage, and GPU/PCI hardware. What would you like to know?"
            tool = matches[0]
        self.last_tool = tool
        self.last_output = run_readonly_tool(tool)
        labels = {"cpu":"CPU information", "memory":"Memory information", "disks":"Disk and storage information", "pci":"PCI/GPU information"}
        return f"{labels[tool]}:\n{self.last_output}"
