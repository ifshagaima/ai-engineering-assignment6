from .assistant import HardwareAssistant

def main():
    assistant = HardwareAssistant()
    print("Local Hardware Q&A Assistant (type 'exit' to quit)")
    while True:
        try:
            question = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if question.lower() in {"exit", "quit"}:
            print("Goodbye!")
            break
        if question:
            print("\nAssistant:", assistant.answer(question))

if __name__ == "__main__":
    main()
