"""Safe hardware inspection: fixed read-only commands only; never accepts shell input."""
import platform, shutil, subprocess
from pathlib import Path

ALLOWED_COMMANDS = {
    "cpu": ["lscpu"],
    "memory": ["free", "-h"],
    "disks": ["lsblk", "-o", "NAME,SIZE,TYPE,MOUNTPOINT,MODEL"],
    "pci": ["lspci"],
}
MOCK = {
    "cpu": "Architecture: x86_64\nModel name: Demo Intel Core i5\nCPU(s): 8",
    "memory": "Mem: 16Gi total, 6Gi used, 8Gi free, 2Gi shared",
    "disks": "NAME SIZE TYPE MOUNTPOINT MODEL\nsda 512G disk / Demo SSD",
    "pci": "00:02.0 VGA compatible controller: Demo integrated graphics",
}

def run_readonly_tool(tool_name: str) -> str:
    if tool_name not in ALLOWED_COMMANDS:
        raise ValueError("Tool is not allow-listed")
    if platform.system() != "Linux":
        return MOCK[tool_name] + "\n[DEMO DATA: live hardware inspection requires Linux]"
    command = ALLOWED_COMMANDS[tool_name]
    executable = shutil.which(command[0])
    if not executable:
        return f"{command[0]} is not installed on this Linux system."
    try:
        result = subprocess.run([executable, *command[1:]], capture_output=True, text=True, timeout=10, check=False)
        if result.returncode != 0:
            return (result.stderr or "Command failed").strip()
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return f"{command[0]} timed out."

def inspect_proc(path: str) -> str:
    """Read only specific safe proc files; reject arbitrary paths."""
    allowed = {"/proc/meminfo", "/proc/cpuinfo", "/proc/partitions"}
    if path not in allowed:
        raise ValueError("File is not allow-listed")
    try:
        return Path(path).read_text(encoding="utf-8", errors="replace")[:12000]
    except OSError as exc:
        return f"Unable to read {path}: {exc}"

def hardware_snapshot() -> dict[str, str]:
    return {name: run_readonly_tool(name) for name in ALLOWED_COMMANDS}
