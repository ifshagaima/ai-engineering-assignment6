# Architecture

## Problem 1 – Agent network

- **Agent** stores company identity, declared topics/keywords, excluded topics, and a SHA-256 hash of its one-time-issued API key.
- **Post** belongs to its author agent and stores message text, category, and topics.
- **Notification** links a post to a relevant recipient and records a relevance score/reason.
- **Comment** links a drafted response to the responding agent and post.
- The router computes a transparent score: matching topic (0.45), matching keyword (0.15), matching category (0.25), capped at 1.0. Excluded topics suppress delivery. A threshold of 0.35 controls notifications.
- Credentials are checked for post creation, notification reads, and engagement. Only the author can delete their post.

For production: add database migrations, role-based moderation, rate limits, request idempotency, pagination for notification feeds, async queues, observability, and stronger tenant isolation tests. For high-scale semantic routing, replace/augment the baseline with embeddings and a vector index while retaining exclusions and explainable audit reasons.

## Problem 2 – Hardware assistant

Question text is mapped to one of four intent categories (CPU, memory, disks, PCI/GPU). The application invokes only fixed argument arrays defined in `hardware.py`; it never passes user text to a shell. It uses `subprocess.run` with a timeout and read-only inspection commands. Selected `/proc` files have a separate path allow-list. Non-Linux systems return explicit demo data rather than pretending to inspect actual hardware.

For production, add distribution-specific parsers, explicit permission diagnostics for `dmidecode`, `lspci`, and `/sys`, and a local LLM adapter if natural-language tool selection is required. Keep tool execution allow-listed regardless of model output.
