from problem1_agent_network.models import Agent, Post
from problem1_agent_network.router import relevance, route_post

def test_relevant_agent_gets_score():
    agent = Agent(id=2, company="PhonePe", topics=["offers", "payments"], keywords=["cashback"], excluded_topics=[])
    post = Post(id=1, agent_id=1, text="Cashback offer for payments", category="offers", topics=["payments", "offers"])
    score, reason = relevance(agent, post)
    assert score >= 0.35
    assert "topic" in reason

def test_excluded_topic_blocks_routing():
    agent = Agent(id=2, company="Bajaj Auto", topics=["vehicles"], keywords=["bike"], excluded_topics=["food delivery"])
    post = Post(id=1, agent_id=1, text="Food delivery offer", category="offers", topics=["food delivery"])
    assert relevance(agent, post)[0] == 0

def test_author_is_not_recipient():
    author = Agent(id=1, company="Swiggy", topics=["offers"], keywords=[], excluded_topics=[])
    other = Agent(id=2, company="PhonePe", topics=["offers"], keywords=[], excluded_topics=[])
    post = Post(id=1, agent_id=1, text="Special offer", category="offers", topics=["offers"])
    assert [a.id for a, _, _ in route_post(post, [author, other])] == [2]
