import pytest
from problem2_hardware_assistant.hardware import run_readonly_tool, inspect_proc
from problem2_hardware_assistant.assistant import HardwareAssistant

def test_allow_list_rejects_unknown_tool():
    with pytest.raises(ValueError):
        run_readonly_tool("shell")

def test_proc_path_allow_list():
    with pytest.raises(ValueError):
        inspect_proc("/etc/passwd")

def test_assistant_maps_ram_question():
    assistant = HardwareAssistant()
    answer = assistant.answer("How much RAM do I have?")
    assert "Memory information" in answer
